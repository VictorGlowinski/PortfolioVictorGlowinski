export const CONFIG = {
  API_BASE_URL: "https://kinesis.sh1.hidora.com/api",
  //API_BASE_URL: "http://192.168.0.112:8000/api",

  TIMEOUT: 5000,
  RETRIES: 3
};