import React from 'react';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import { Link, Tabs } from 'expo-router';
import { Pressable } from 'react-native';

import Colors from '@/constants/Colors';
import { useColorScheme } from '@/components/useColorScheme';
import { useClientOnlyValue } from '@/components/useClientOnlyValue';


// You can explore the built-in icon families and icons on the web at https://icons.expo.fyi/
function TabBarIcon(props: {
  name: React.ComponentProps<typeof FontAwesome>['name'];
  color: string;
}) {
  return <FontAwesome size={28} style={{ marginBottom: -3 }} {...props} />;
}

// app/(tabs)/_layout.tsx - CORRIGER la duplication

export default function TabLayout() {
  const colorScheme = useColorScheme();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors[colorScheme ?? 'light'].tint,
        headerShown: useClientOnlyValue(false, true),
      }}>
      
      {/* Onglet Accueil */}
      <Tabs.Screen
        name="index"
        options={{
          title: 'Accueil',
          tabBarIcon: ({ color }) => <TabBarIcon name="home" color={color} />,
          
        }}
      />

      {/* ✅ Onglet Plans d'entraînement - GARDER SEULEMENT CELUI-CI */}
      <Tabs.Screen
        name="plan"
        options={{
          title: 'Plans',
          tabBarIcon: ({ color }) => <TabBarIcon name="list-alt" color={color} />,
          // ✅ SUPPRIMER le headerRight qui pointe vers lui-même
        }}
      />


      {/* Onglet Profil */}
      <Tabs.Screen
        name="profil"
        options={{
          title: 'Profil',
          tabBarIcon: ({ color }) => <TabBarIcon name="user" color={color} />,
        }}
      />

      {/* Masquer les pages non utilisées dans les onglets */}
      <Tabs.Screen
        name="two"
        options={{
          href: null, // Masque cet onglet
        }}
      />

      <Tabs.Screen
        name="creationAnamnese"
        options={{
          href: null, // Masque cet onglet (sera accessible via navigation)
        }}
      />

      <Tabs.Screen
        name="creationEvaluationInitiale"
        options={{
          href: null, // Masque cet onglet (sera accessible via navigation)
        }}
      />
      
    </Tabs>
  );
}